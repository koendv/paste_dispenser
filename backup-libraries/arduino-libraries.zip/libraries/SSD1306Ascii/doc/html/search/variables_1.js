var searchData=
[
  ['coloffset',['colOffset',['../struct_dev_type.html#a9ffb262e6ccb78389abd291fd446c071',1,'DevType']]]
];
